
/*
Sebastian Juncos A01022629
11/26/2018
Proyect
*/
import java.util.*;
import java.io.*;

public class Intento4 {
	public static String[][] valorAlimentos = new String[40][4];
	public static String[][] valorLimites = new String[10][4];
	public static String fileAli = "PruebaAlimentos.txt";
	public static File file1 = new File(fileAli);
	public static String fileLim = "PruebaLimites.txt";
	public static File file2 = new File(fileLim);
	public static Scanner s;

	public static void main(String[] args) throws IOException {
		Scanner kb = new Scanner(System.in);
		int r = 0, i = 0, j = 0;// seleccion y valores de contadores
		String comida = " ", como = " ";// datos para registrar la comida
		Double calTot = 0.0;// Calorias totales para Limites
		Double contAlim = 0.0;// convertidor a unidades
		Double valor = 0.0;// porciones/unidades
		int enLim = 0;// Ubica categoria para tipo de comida
		Double opPorcion = 0.0;// Guarda los gramos del alimento
		Double opCalorias = 0.0;// Guarda las calorias de una unidad de alimento
		Double porcionesTot = 0.0;// acumula el numero de porciones en cada categoria
		boolean salir = true;// hace que el programa se cierre al poner la opcion 4
		valorAlimentos = readValorAlimentos();
		valorLimites = readValorLimites();
		while (salir) {
			System.out.println(
					"Que quieres hacer hoy? \n1.	Registrar Comida \n2.	Ver Resumen \n3.	Reiniciar Datos \n4.	Guardar y Salir \n");
			Scanner keyboard = new Scanner(System.in);
			r = kb.nextInt();
			switch (r) {
			case 1:
				System.out.println("Que comiste? ");
				comida = (kb.next()).toLowerCase();
				for (i = 0; i < 39; i++) {
					if (valorAlimentos[i][1].equals(comida)) {
						enLim = Integer.parseInt(valorAlimentos[i][0]);
						opPorcion = Double.parseDouble(valorAlimentos[i][2]);
						opCalorias = Double.parseDouble(valorAlimentos[i][3]);
					} // if end
				} // for end
					// int ubix=Integer.parseInt(valorAlimentos[i][j]);
					// System.out.println(ubix);
				System.out.println(enLim);
				System.out.println(opPorcion);
				System.out.println(opCalorias);
				System.out.println("Como lo queires regirstrar? \nUnidades o porciones? \nSe recomiendan unidades");
				como = (keyboard.next()).toLowerCase();
				if (como.equals("porciones")) {
					System.out.println("Cuantos gramos consumiste?");
					valor = kb.nextDouble();
					valor = (valor / opPorcion);
					calTot += valor * opCalorias;
					for (i = 1; i < 10; i++) {
						if (valorLimites[i][0].equals(Integer.toString(enLim))) {
							porcionesTot = Double.parseDouble(valorLimites[i][3]);
							porcionesTot += valor;
							calTot = Double.parseDouble(valorLimites[9][3]);
							valorLimites[i][3] = Double.toString(porcionesTot);
							valorLimites[9][3] = Double.toString(calTot);
						} // if end
					} // nested for end
				} // if end
				else if (como.equals("unidades")) {
					System.out.println("Cuantas unidades te comiste?");
					valor = kb.nextDouble();
					calTot += valor * opCalorias;
					for (i = 0; i < 6; i++) {
						if (valorLimites[i][0].equals(Integer.toString(enLim))) {
							porcionesTot = Double.parseDouble(valorLimites[i][3]);
							porcionesTot += valor;
							calTot = Double.parseDouble(valorLimites[i][3]);
							calTot += valor * opCalorias;
							valorLimites[i][3] = Double.toString(porcionesTot);
							valorLimites[9][3] = Double.toString(calTot);
						} // if end
					} // for end
				} // else if end
				break;
			case 2:
				for (i = 0; i < valorLimites.length; i++) {
					for (j = 0; j < valorLimites[0].length; j++) {
						System.out.print(valorLimites[i][j] + " ");
					} // nested for end
					System.out.println();
				} // for end
				break;
			case 3:
				for (i = 1; i < valorLimites.length; i++) {
					for (j = 3; j < valorLimites[1].length; j++) {
						valorLimites[i][j] = "0";
					} // nested for end
				} // for end
				System.out.println("Todos los valores se encuentran en 0");
				// Reiniciar();
				break;
			case 4:
				PrintWriter theOutput = new PrintWriter("PruebaLimites.txt");
				for (i = 0; i < valorLimites.length; i++) {
					for (j = 0; j < valorLimites[0].length; j++) {
						theOutput.print(valorLimites[i][j] + ",");
					} // nested for end
					theOutput.println();
				} // for end
				theOutput.close();
				// GuardarTodo();
				salir = false;
				break;
			default:
				System.out.println("Porfavor teclea un numero diferente");
				break;
			}// switch end
		} // while end
	}// main end

	// Reading
	// stuff-------------------------------------------------------------------------------------------
	// Procesos:
	public static String[][] readValorAlimentos() {
		String linea = "";
		String[] array;
		int cont = 0;
		valorAlimentos = new String[40][4];
		try {
			s = new Scanner(file1);
			while (s.hasNext()) {
				linea = s.nextLine();
				array = linea.split(",");
				valorAlimentos[cont] = array;
				cont++;
			} // while end
		} // try end
		catch (Exception e) {
			System.out.println("Error");
		} // exception end
		return valorAlimentos;
	}// readValorAlimentos end

	public static String[][] readValorLimites() {
		String linea = "";
		String[] array;
		int cont = 0;
		valorLimites = new String[10][4];
		try {
			s = new Scanner(file2);
			while (s.hasNext()) {
				linea = s.nextLine();
				array = linea.split(",");
				valorLimites[cont] = array;
				cont++;
			} // while end
		} // try end
		catch (Exception e) {
			System.out.println("Error");
		} // catch end
		return valorLimites;
	}// radValorLimites end
}// intento 4 end